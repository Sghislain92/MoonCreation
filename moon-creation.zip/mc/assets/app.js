(()=>{const L=k=>{try{return JSON.parse(localStorage.getItem(k)||'[]')}catch{return[]}},S=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
const $=(s,r=document)=>[...r.querySelectorAll(s)],M=window.MC||{};
function sync(){const c=L('mc_cart').reduce((a,x)=>a+x.q,0),f=L('mc_fav');$('[data-count=cart]').forEach(e=>{e.textContent=c;e.hidden=!c});$('[data-count=fav]').forEach(e=>{e.textContent=f.length;e.hidden=!f.length});$('[data-fav]').forEach(b=>{const on=f.includes(+b.dataset.fav);b.setAttribute('aria-pressed',on);b.firstElementChild.setAttribute('fill',on?'#B4405F':'none')});
if(new URLSearchParams(location.search).has('favoris'))$('[data-card]').forEach(c=>c.hidden=!f.includes(+c.dataset.card))}
function cart(){const el=document.getElementById('cart');if(!el)return;const c=L('mc_cart');if(!c.length){el.innerHTML='<p class="py-16 text-center text-mc-muted">Votre panier est vide.</p>';return}
let t=0,m='Bonjour Moon Création, je souhaite commander :\n';el.innerHTML=c.map(x=>{const p=M.p[x.id];t+=p.p*x.q;m+='• '+x.q+' × '+p.n+' — '+p.p*x.q+' FCFA\n';return `<div class="flex items-center gap-3 border-b border-mc-line py-3"><img src="${p.img}" class="h-20 w-20 rounded-[10px] object-cover" alt=""><div class="min-w-0 flex-1"><p class="truncate">${p.n}</p><p class="font-bold text-mc-wine">${p.p.toLocaleString('fr-FR')} FCFA</p></div><div class="flex items-center gap-2"><button data-q="${x.id},-1" class="h-8 w-8 rounded-full border border-mc-line">−</button><span>${x.q}</span><button data-q="${x.id},1" class="h-8 w-8 rounded-full border border-mc-line">+</button></div></div>`}).join('')+`<p class="mt-4 flex justify-between text-lg font-bold"><span>Total</span><span>${t.toLocaleString('fr-FR')} FCFA</span></p><a href="https://wa.me/${M.wa}?text=${encodeURIComponent(m+'Total : '+t+' FCFA')}" class="mt-4 flex h-12 items-center justify-center rounded-full bg-mc-wine text-white">Commander sur WhatsApp</a>`}
document.addEventListener('click',e=>{const a=e.target.closest('[data-add]'),f=e.target.closest('[data-fav]'),q=e.target.closest('[data-q]'),mo=e.target.closest('[data-more]');
if(a){e.preventDefault();const c=L('mc_cart'),i=c.find(x=>x.id==a.dataset.add);i?i.q++:c.push({id:+a.dataset.add,q:1});S('mc_cart',c)}
if(f){e.preventDefault();let v=L('mc_fav');const id=+f.dataset.fav;v=v.includes(id)?v.filter(x=>x!=id):[...v,id];S('mc_fav',v)}
if(q){const[id,d]=q.dataset.q.split(',');let c=L('mc_cart');c.forEach(x=>{if(x.id==id)x.q+=+d});S('mc_cart',c.filter(x=>x.q>0))}
if(mo){const h=$('#all [data-card][hidden]').slice(0,8);h.forEach(x=>x.hidden=false);if(h.length<=8)mo.remove();return}
sync();cart()});
$('#all [data-card]').forEach((c,i)=>{if(i>=8)c.hidden=true});sync();cart();
if('serviceWorker'in navigator)addEventListener('load',()=>navigator.serviceWorker.register(M.base+'/sw.js'));
})();
