<?php
// Tout ce qui est modifiable est ici.
return [
 'name'=>'Moon Création','tag'=>'BIJOUX • SENSUALITÉ • LUXE','wa'=>'22969384533',
 'img'=>'https://www.websoftenterprise.com/mooncreation/images/', // remplacer par vos images locales
 'font'=>"'Cormorant Garamond'", // PROVISOIRE : mettre la police actuelle de Moon Création
 'fontUrl'=>'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Great+Vibes&display=swap',
 'trust'=>[['truck','Livraison discrète','Bénin et international'],['chat','Conseil','Sur WhatsApp'],['card','Paiement','À confirmer sur WhatsApp']],
];
